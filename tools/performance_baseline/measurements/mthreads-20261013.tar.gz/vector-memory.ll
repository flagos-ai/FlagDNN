; ModuleID = 'tools/performance_baseline/benchmark_mthreads_vector_memory.mu'
source_filename = "tools/performance_baseline/benchmark_mthreads_vector_memory.mu"
target datalayout = "e-p:64:64:64:64-p1:64:64:64:64-p2:64:64:64:64-p3:32:32-p4:32:32-p5:64:64-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128"
target triple = "mtgpu-mt-musa"

%struct.uint4 = type { i32, i32, i32, i32 }

; Function Attrs: convergent mustprogress nofree norecurse nounwind writeonly
define protected mtgpu_kernel void @_Z17initialize_memoryP5uint4S0_S0_m(%struct.uint4* nocapture noundef writeonly %0, %struct.uint4* nocapture noundef writeonly %1, %struct.uint4* nocapture noundef writeonly %2, i64 noundef %3) local_unnamed_addr #0 !mtgpu.promoted.alloca.size_in_bits !10 {
  %5 = tail call i32 @llvm.musa.read.ptx.sreg.ctaid.x() #6
  %6 = zext i32 %5 to i64
  %7 = tail call i32 @llvm.musa.read.ptx.sreg.ntid.x() #6
  %8 = zext i32 %7 to i64
  %9 = mul nuw i64 %8, %6
  %10 = tail call i32 @llvm.musa.read.ptx.sreg.tid.x() #6
  %11 = zext i32 %10 to i64
  %12 = add nuw i64 %9, %11
  %13 = icmp ult i64 %12, %3
  br i1 %13, label %14, label %18

14:                                               ; preds = %4
  %15 = tail call i32 @llvm.musa.read.ptx.sreg.nctaid.x() #6
  %16 = zext i32 %15 to i64
  %17 = mul nuw i64 %16, %8
  br label %19

18:                                               ; preds = %19, %4
  ret void

19:                                               ; preds = %14, %19
  %20 = phi i64 [ %12, %14 ], [ %119, %19 ]
  %21 = trunc i64 %20 to i32
  %22 = shl i32 %21, 2
  %23 = lshr i32 %22, 16
  %24 = xor i32 %23, %22
  %25 = mul i32 %24, 2146121005
  %26 = lshr i32 %25, 15
  %27 = xor i32 %26, %25
  %28 = mul i32 %27, -2073254261
  %29 = lshr i32 %28, 16
  %30 = and i32 %28, 8388607
  %31 = xor i32 %30, %29
  %32 = or i32 %31, 1056964608
  %33 = or i32 %22, 1
  %34 = xor i32 %33, %23
  %35 = mul i32 %34, 2146121005
  %36 = lshr i32 %35, 15
  %37 = xor i32 %36, %35
  %38 = mul i32 %37, -2073254261
  %39 = lshr i32 %38, 16
  %40 = and i32 %38, 8388607
  %41 = xor i32 %40, %39
  %42 = or i32 %41, 1056964608
  %43 = or i32 %22, 2
  %44 = xor i32 %43, %23
  %45 = mul i32 %44, 2146121005
  %46 = lshr i32 %45, 15
  %47 = xor i32 %46, %45
  %48 = mul i32 %47, -2073254261
  %49 = lshr i32 %48, 16
  %50 = and i32 %48, 8388607
  %51 = xor i32 %50, %49
  %52 = or i32 %51, 1056964608
  %53 = or i32 %22, 3
  %54 = xor i32 %53, %23
  %55 = mul i32 %54, 2146121005
  %56 = lshr i32 %55, 15
  %57 = xor i32 %56, %55
  %58 = mul i32 %57, -2073254261
  %59 = lshr i32 %58, 16
  %60 = and i32 %58, 8388607
  %61 = xor i32 %60, %59
  %62 = or i32 %61, 1056964608
  %63 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %20, i32 0
  store i32 %32, i32* %63, align 16, !tbaa.struct !11
  %64 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %20, i32 1
  store i32 %42, i32* %64, align 4, !tbaa.struct !16
  %65 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %20, i32 2
  store i32 %52, i32* %65, align 8, !tbaa.struct !17
  %66 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %20, i32 3
  store i32 %62, i32* %66, align 4, !tbaa.struct !18
  %67 = add i32 %22, 20281789
  %68 = lshr i32 %67, 16
  %69 = xor i32 %68, %67
  %70 = mul i32 %69, 2146121005
  %71 = lshr i32 %70, 15
  %72 = xor i32 %71, %70
  %73 = mul i32 %72, -2073254261
  %74 = lshr i32 %73, 16
  %75 = and i32 %73, 8388607
  %76 = xor i32 %75, %74
  %77 = or i32 %76, 1056964608
  %78 = add i32 %22, 20281790
  %79 = lshr i32 %78, 16
  %80 = xor i32 %79, %78
  %81 = mul i32 %80, 2146121005
  %82 = lshr i32 %81, 15
  %83 = xor i32 %82, %81
  %84 = mul i32 %83, -2073254261
  %85 = lshr i32 %84, 16
  %86 = and i32 %84, 8388607
  %87 = xor i32 %86, %85
  %88 = or i32 %87, 1056964608
  %89 = add i32 %22, 20281791
  %90 = lshr i32 %89, 16
  %91 = xor i32 %90, %89
  %92 = mul i32 %91, 2146121005
  %93 = lshr i32 %92, 15
  %94 = xor i32 %93, %92
  %95 = mul i32 %94, -2073254261
  %96 = lshr i32 %95, 16
  %97 = and i32 %95, 8388607
  %98 = xor i32 %97, %96
  %99 = or i32 %98, 1056964608
  %100 = add i32 %22, 20281792
  %101 = lshr i32 %100, 16
  %102 = xor i32 %101, %100
  %103 = mul i32 %102, 2146121005
  %104 = lshr i32 %103, 15
  %105 = xor i32 %104, %103
  %106 = mul i32 %105, -2073254261
  %107 = lshr i32 %106, 16
  %108 = and i32 %106, 8388607
  %109 = xor i32 %108, %107
  %110 = or i32 %109, 1056964608
  %111 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %20, i32 0
  store i32 %77, i32* %111, align 16, !tbaa.struct !11
  %112 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %20, i32 1
  store i32 %88, i32* %112, align 4, !tbaa.struct !16
  %113 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %20, i32 2
  store i32 %99, i32* %113, align 8, !tbaa.struct !17
  %114 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %20, i32 3
  store i32 %110, i32* %114, align 4, !tbaa.struct !18
  %115 = getelementptr inbounds %struct.uint4, %struct.uint4* %2, i64 %20, i32 0
  store i32 0, i32* %115, align 16, !tbaa.struct !11
  %116 = getelementptr inbounds %struct.uint4, %struct.uint4* %2, i64 %20, i32 1
  store i32 0, i32* %116, align 4, !tbaa.struct !16
  %117 = getelementptr inbounds %struct.uint4, %struct.uint4* %2, i64 %20, i32 2
  store i32 0, i32* %117, align 8, !tbaa.struct !17
  %118 = getelementptr inbounds %struct.uint4, %struct.uint4* %2, i64 %20, i32 3
  store i32 0, i32* %118, align 4, !tbaa.struct !18
  %119 = add i64 %17, %20
  %120 = icmp ult i64 %119, %3
  br i1 %120, label %19, label %18, !llvm.loop !19
}

; Function Attrs: convergent mustprogress nofree norecurse nounwind
define protected mtgpu_kernel void @_Z11memory_copyPK5uint4PS_m(%struct.uint4* nocapture noundef readonly %0, %struct.uint4* nocapture noundef writeonly %1, i64 noundef %2) local_unnamed_addr #1 !mtgpu.promoted.alloca.size_in_bits !10 {
  %4 = tail call i32 @llvm.musa.read.ptx.sreg.ctaid.x() #6
  %5 = zext i32 %4 to i64
  %6 = tail call i32 @llvm.musa.read.ptx.sreg.ntid.x() #6
  %7 = zext i32 %6 to i64
  %8 = mul nuw i64 %7, %5
  %9 = tail call i32 @llvm.musa.read.ptx.sreg.tid.x() #6
  %10 = zext i32 %9 to i64
  %11 = add nuw i64 %8, %10
  %12 = icmp ult i64 %11, %2
  br i1 %12, label %13, label %17

13:                                               ; preds = %3
  %14 = tail call i32 @llvm.musa.read.ptx.sreg.nctaid.x() #6
  %15 = zext i32 %14 to i64
  %16 = mul nuw i64 %15, %7
  br label %18

17:                                               ; preds = %18, %3
  ret void

18:                                               ; preds = %13, %18
  %19 = phi i64 [ %11, %13 ], [ %32, %18 ]
  %20 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %19, i32 0
  %21 = load i32, i32* %20, align 16, !tbaa.struct !11
  %22 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %19, i32 1
  %23 = load i32, i32* %22, align 4, !tbaa.struct !16
  %24 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %19, i32 2
  %25 = load i32, i32* %24, align 8, !tbaa.struct !17
  %26 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %19, i32 3
  %27 = load i32, i32* %26, align 4, !tbaa.struct !18
  %28 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %19, i32 0
  store i32 %21, i32* %28, align 16, !tbaa.struct !11
  %29 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %19, i32 1
  store i32 %23, i32* %29, align 4, !tbaa.struct !16
  %30 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %19, i32 2
  store i32 %25, i32* %30, align 8, !tbaa.struct !17
  %31 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %19, i32 3
  store i32 %27, i32* %31, align 4, !tbaa.struct !18
  %32 = add i64 %16, %19
  %33 = icmp ult i64 %32, %2
  br i1 %33, label %18, label %17, !llvm.loop !21
}

; Function Attrs: convergent mustprogress nofree norecurse nounwind
define protected mtgpu_kernel void @_Z12memory_writeP5uint4m(%struct.uint4* nocapture noundef writeonly %0, i64 noundef %1) local_unnamed_addr #1 !mtgpu.promoted.alloca.size_in_bits !10 {
  %3 = tail call i32 @llvm.musa.read.ptx.sreg.ctaid.x() #6
  %4 = zext i32 %3 to i64
  %5 = tail call i32 @llvm.musa.read.ptx.sreg.ntid.x() #6
  %6 = zext i32 %5 to i64
  %7 = mul nuw i64 %6, %4
  %8 = tail call i32 @llvm.musa.read.ptx.sreg.tid.x() #6
  %9 = zext i32 %8 to i64
  %10 = add nuw i64 %7, %9
  %11 = icmp ult i64 %10, %1
  br i1 %11, label %12, label %16

12:                                               ; preds = %2
  %13 = tail call i32 @llvm.musa.read.ptx.sreg.nctaid.x() #6
  %14 = zext i32 %13 to i64
  %15 = mul nuw i64 %14, %6
  br label %17

16:                                               ; preds = %17, %2
  ret void

17:                                               ; preds = %12, %17
  %18 = phi i64 [ %10, %12 ], [ %30, %17 ]
  %19 = trunc i64 %18 to i32
  %20 = mul i32 %19, 1664525
  %21 = add i32 %20, 1013904223
  %22 = xor i32 %19, -1515870811
  %23 = mul i32 %19, 747796405
  %24 = add i32 %23, -1403630843
  %25 = xor i32 %19, 1013904242
  %26 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %18, i32 0
  store i32 %21, i32* %26, align 16, !tbaa.struct !11
  %27 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %18, i32 1
  store i32 %22, i32* %27, align 4, !tbaa.struct !16
  %28 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %18, i32 2
  store i32 %24, i32* %28, align 8, !tbaa.struct !17
  %29 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %18, i32 3
  store i32 %25, i32* %29, align 4, !tbaa.struct !18
  %30 = add i64 %15, %18
  %31 = icmp ult i64 %30, %1
  br i1 %31, label %17, label %16, !llvm.loop !22
}

; Function Attrs: convergent mustprogress nofree norecurse nounwind
define protected mtgpu_kernel void @_Z11memory_readPK5uint4PS_m(%struct.uint4* nocapture noundef readonly %0, %struct.uint4* nocapture noundef writeonly %1, i64 noundef %2) local_unnamed_addr #1 !mtgpu.promoted.alloca.size_in_bits !10 {
  %4 = tail call i32 @llvm.musa.read.ptx.sreg.ctaid.x() #6
  %5 = zext i32 %4 to i64
  %6 = tail call i32 @llvm.musa.read.ptx.sreg.ntid.x() #6
  %7 = zext i32 %6 to i64
  %8 = mul nuw i64 %7, %5
  %9 = tail call i32 @llvm.musa.read.ptx.sreg.tid.x() #6
  %10 = zext i32 %9 to i64
  %11 = add nuw i64 %8, %10
  %12 = icmp ult i64 %11, %2
  br i1 %12, label %13, label %17

13:                                               ; preds = %3
  %14 = tail call i32 @llvm.musa.read.ptx.sreg.nctaid.x() #6
  %15 = zext i32 %14 to i64
  %16 = mul nuw i64 %15, %7
  br label %26

17:                                               ; preds = %26, %3
  %18 = phi i32 [ 0, %3 ], [ %40, %26 ]
  %19 = phi i32 [ 0, %3 ], [ %41, %26 ]
  %20 = phi i32 [ 0, %3 ], [ %42, %26 ]
  %21 = phi i32 [ 0, %3 ], [ %43, %26 ]
  %22 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %11, i32 0
  store i32 %18, i32* %22, align 16, !tbaa.struct !11
  %23 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %11, i32 1
  store i32 %19, i32* %23, align 4, !tbaa.struct !16
  %24 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %11, i32 2
  store i32 %20, i32* %24, align 8, !tbaa.struct !17
  %25 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %11, i32 3
  store i32 %21, i32* %25, align 4, !tbaa.struct !18
  ret void

26:                                               ; preds = %13, %26
  %27 = phi i32 [ 0, %13 ], [ %43, %26 ]
  %28 = phi i32 [ 0, %13 ], [ %42, %26 ]
  %29 = phi i32 [ 0, %13 ], [ %41, %26 ]
  %30 = phi i32 [ 0, %13 ], [ %40, %26 ]
  %31 = phi i64 [ %11, %13 ], [ %44, %26 ]
  %32 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %31, i32 0
  %33 = load i32, i32* %32, align 16, !tbaa.struct !11
  %34 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %31, i32 1
  %35 = load i32, i32* %34, align 4, !tbaa.struct !16
  %36 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %31, i32 2
  %37 = load i32, i32* %36, align 8, !tbaa.struct !17
  %38 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %31, i32 3
  %39 = load i32, i32* %38, align 4, !tbaa.struct !18
  %40 = xor i32 %33, %30
  %41 = xor i32 %35, %29
  %42 = xor i32 %37, %28
  %43 = xor i32 %39, %27
  %44 = add i64 %16, %31
  %45 = icmp ult i64 %44, %2
  br i1 %45, label %26, label %17, !llvm.loop !23
}

; Function Attrs: convergent nofree norecurse nounwind
define protected mtgpu_kernel void @_Z12memory_triadPK5uint4S1_PS_mf(%struct.uint4* nocapture noundef readonly %0, %struct.uint4* nocapture noundef readonly %1, %struct.uint4* nocapture noundef writeonly %2, i64 noundef %3, float noundef %4) local_unnamed_addr #2 !mtgpu.promoted.alloca.size_in_bits !10 {
  %6 = tail call i32 @llvm.musa.read.ptx.sreg.ctaid.x() #6
  %7 = zext i32 %6 to i64
  %8 = tail call i32 @llvm.musa.read.ptx.sreg.ntid.x() #6
  %9 = zext i32 %8 to i64
  %10 = mul nuw i64 %9, %7
  %11 = tail call i32 @llvm.musa.read.ptx.sreg.tid.x() #6
  %12 = zext i32 %11 to i64
  %13 = add nuw i64 %10, %12
  %14 = icmp ult i64 %13, %3
  br i1 %14, label %15, label %19

15:                                               ; preds = %5
  %16 = tail call i32 @llvm.musa.read.ptx.sreg.nctaid.x() #6
  %17 = zext i32 %16 to i64
  %18 = mul nuw i64 %17, %9
  br label %20

19:                                               ; preds = %20, %5
  ret void

20:                                               ; preds = %15, %20
  %21 = phi i64 [ %13, %15 ], [ %58, %20 ]
  %22 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %21
  %23 = bitcast %struct.uint4* %22 to float*
  %24 = load float, float* %23, align 16, !tbaa.struct !11
  %25 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %21, i32 1
  %26 = bitcast i32* %25 to float*
  %27 = load float, float* %26, align 4, !tbaa.struct !16
  %28 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %21, i32 2
  %29 = bitcast i32* %28 to float*
  %30 = load float, float* %29, align 8, !tbaa.struct !17
  %31 = getelementptr inbounds %struct.uint4, %struct.uint4* %0, i64 %21, i32 3
  %32 = bitcast i32* %31 to float*
  %33 = load float, float* %32, align 4, !tbaa.struct !18
  %34 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %21
  %35 = bitcast %struct.uint4* %34 to float*
  %36 = load float, float* %35, align 16, !tbaa.struct !11
  %37 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %21, i32 1
  %38 = bitcast i32* %37 to float*
  %39 = load float, float* %38, align 4, !tbaa.struct !16
  %40 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %21, i32 2
  %41 = bitcast i32* %40 to float*
  %42 = load float, float* %41, align 8, !tbaa.struct !17
  %43 = getelementptr inbounds %struct.uint4, %struct.uint4* %1, i64 %21, i32 3
  %44 = bitcast i32* %43 to float*
  %45 = load float, float* %44, align 4, !tbaa.struct !18
  %46 = tail call contract float @llvm.fma.f32(float %4, float %36, float %24) #6
  %47 = tail call contract float @llvm.fma.f32(float %4, float %39, float %27) #6
  %48 = tail call contract float @llvm.fma.f32(float %4, float %42, float %30) #6
  %49 = tail call contract float @llvm.fma.f32(float %4, float %45, float %33) #6
  %50 = getelementptr inbounds %struct.uint4, %struct.uint4* %2, i64 %21
  %51 = bitcast %struct.uint4* %50 to float*
  store float %46, float* %51, align 16, !tbaa.struct !11
  %52 = getelementptr inbounds %struct.uint4, %struct.uint4* %2, i64 %21, i32 1
  %53 = bitcast i32* %52 to float*
  store float %47, float* %53, align 4, !tbaa.struct !16
  %54 = getelementptr inbounds %struct.uint4, %struct.uint4* %2, i64 %21, i32 2
  %55 = bitcast i32* %54 to float*
  store float %48, float* %55, align 8, !tbaa.struct !17
  %56 = getelementptr inbounds %struct.uint4, %struct.uint4* %2, i64 %21, i32 3
  %57 = bitcast i32* %56 to float*
  store float %49, float* %57, align 4, !tbaa.struct !18
  %58 = add i64 %18, %21
  %59 = icmp ult i64 %58, %3
  br i1 %59, label %20, label %19, !llvm.loop !24
}

; Function Attrs: convergent nofree nounwind readnone
declare i32 @llvm.musa.read.ptx.sreg.ctaid.x() #3

; Function Attrs: nofree nosync nounwind readnone
declare i32 @llvm.musa.read.ptx.sreg.ntid.x() #4

; Function Attrs: nofree nosync nounwind readnone
declare i32 @llvm.musa.read.ptx.sreg.tid.x() #4

; Function Attrs: nofree nosync nounwind readnone
declare i32 @llvm.musa.read.ptx.sreg.nctaid.x() #4

; Function Attrs: mustprogress nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.fma.f32(float, float, float) #5

; Function Attrs: convergent mustprogress nofree norecurse nounwind writeonly
define protected mtgpu_kernel void @_Z11compute_fmaI4FP32EvPNT_1TEiS2_S2_(float* nocapture noundef writeonly %0, i32 noundef %1, float noundef %2, float noundef %3) local_unnamed_addr #0 !mtgpu.promoted.alloca.size_in_bits !25 {
  %5 = tail call i32 @llvm.musa.read.ptx.sreg.ctaid.x() #6
  %6 = tail call i32 @llvm.musa.read.ptx.sreg.ntid.x() #6
  %7 = mul i32 %6, %5
  %8 = tail call i32 @llvm.musa.read.ptx.sreg.tid.x() #6
  %9 = add i32 %7, %8
  %10 = and i32 %9, 7
  %11 = uitofp i32 %10 to float
  %12 = fmul contract float %11, 6.250000e-02
  %13 = fadd contract float %12, 1.000000e+00
  %14 = insertelement <8 x float> undef, float %13, i64 0
  %15 = add nuw nsw i32 %10, 1
  %16 = uitofp i32 %15 to float
  %17 = fmul contract float %16, 6.250000e-02
  %18 = fadd contract float %17, 1.000000e+00
  %19 = insertelement <8 x float> %14, float %18, i64 1
  %20 = add nuw nsw i32 %10, 2
  %21 = uitofp i32 %20 to float
  %22 = fmul contract float %21, 6.250000e-02
  %23 = fadd contract float %22, 1.000000e+00
  %24 = insertelement <8 x float> %19, float %23, i64 2
  %25 = add nuw nsw i32 %10, 3
  %26 = uitofp i32 %25 to float
  %27 = fmul contract float %26, 6.250000e-02
  %28 = fadd contract float %27, 1.000000e+00
  %29 = insertelement <8 x float> %24, float %28, i64 3
  %30 = add nuw nsw i32 %10, 4
  %31 = uitofp i32 %30 to float
  %32 = fmul contract float %31, 6.250000e-02
  %33 = fadd contract float %32, 1.000000e+00
  %34 = insertelement <8 x float> %29, float %33, i64 4
  %35 = add nuw nsw i32 %10, 5
  %36 = uitofp i32 %35 to float
  %37 = fmul contract float %36, 6.250000e-02
  %38 = fadd contract float %37, 1.000000e+00
  %39 = insertelement <8 x float> %34, float %38, i64 5
  %40 = add nuw nsw i32 %10, 6
  %41 = uitofp i32 %40 to float
  %42 = fmul contract float %41, 6.250000e-02
  %43 = fadd contract float %42, 1.000000e+00
  %44 = insertelement <8 x float> %39, float %43, i64 6
  %45 = add nuw nsw i32 %10, 7
  %46 = uitofp i32 %45 to float
  %47 = fmul contract float %46, 6.250000e-02
  %48 = fadd contract float %47, 1.000000e+00
  %49 = insertelement <8 x float> %44, float %48, i64 7
  %50 = icmp sgt i32 %1, 0
  br i1 %50, label %51, label %328

51:                                               ; preds = %4, %51
  %52 = phi i32 [ %326, %51 ], [ 0, %4 ]
  %53 = phi <8 x float> [ %325, %51 ], [ %49, %4 ]
  %54 = extractelement <8 x float> %53, i64 0
  %55 = tail call contract float @llvm.musa.fma.rte.f(float %54, float %2, float %3) #6
  %56 = extractelement <8 x float> %53, i64 1
  %57 = tail call contract float @llvm.musa.fma.rte.f(float %56, float %2, float %3) #6
  %58 = extractelement <8 x float> %53, i64 2
  %59 = tail call contract float @llvm.musa.fma.rte.f(float %58, float %2, float %3) #6
  %60 = extractelement <8 x float> %53, i64 3
  %61 = tail call contract float @llvm.musa.fma.rte.f(float %60, float %2, float %3) #6
  %62 = extractelement <8 x float> %53, i64 4
  %63 = tail call contract float @llvm.musa.fma.rte.f(float %62, float %2, float %3) #6
  %64 = extractelement <8 x float> %53, i64 5
  %65 = tail call contract float @llvm.musa.fma.rte.f(float %64, float %2, float %3) #6
  %66 = extractelement <8 x float> %53, i64 6
  %67 = tail call contract float @llvm.musa.fma.rte.f(float %66, float %2, float %3) #6
  %68 = extractelement <8 x float> %53, i64 7
  %69 = tail call contract float @llvm.musa.fma.rte.f(float %68, float %2, float %3) #6
  %70 = tail call contract float @llvm.musa.fma.rte.f(float %55, float %2, float %3) #6
  %71 = tail call contract float @llvm.musa.fma.rte.f(float %57, float %2, float %3) #6
  %72 = tail call contract float @llvm.musa.fma.rte.f(float %59, float %2, float %3) #6
  %73 = tail call contract float @llvm.musa.fma.rte.f(float %61, float %2, float %3) #6
  %74 = tail call contract float @llvm.musa.fma.rte.f(float %63, float %2, float %3) #6
  %75 = tail call contract float @llvm.musa.fma.rte.f(float %65, float %2, float %3) #6
  %76 = tail call contract float @llvm.musa.fma.rte.f(float %67, float %2, float %3) #6
  %77 = tail call contract float @llvm.musa.fma.rte.f(float %69, float %2, float %3) #6
  %78 = tail call contract float @llvm.musa.fma.rte.f(float %70, float %2, float %3) #6
  %79 = tail call contract float @llvm.musa.fma.rte.f(float %71, float %2, float %3) #6
  %80 = tail call contract float @llvm.musa.fma.rte.f(float %72, float %2, float %3) #6
  %81 = tail call contract float @llvm.musa.fma.rte.f(float %73, float %2, float %3) #6
  %82 = tail call contract float @llvm.musa.fma.rte.f(float %74, float %2, float %3) #6
  %83 = tail call contract float @llvm.musa.fma.rte.f(float %75, float %2, float %3) #6
  %84 = tail call contract float @llvm.musa.fma.rte.f(float %76, float %2, float %3) #6
  %85 = tail call contract float @llvm.musa.fma.rte.f(float %77, float %2, float %3) #6
  %86 = tail call contract float @llvm.musa.fma.rte.f(float %78, float %2, float %3) #6
  %87 = tail call contract float @llvm.musa.fma.rte.f(float %79, float %2, float %3) #6
  %88 = tail call contract float @llvm.musa.fma.rte.f(float %80, float %2, float %3) #6
  %89 = tail call contract float @llvm.musa.fma.rte.f(float %81, float %2, float %3) #6
  %90 = tail call contract float @llvm.musa.fma.rte.f(float %82, float %2, float %3) #6
  %91 = tail call contract float @llvm.musa.fma.rte.f(float %83, float %2, float %3) #6
  %92 = tail call contract float @llvm.musa.fma.rte.f(float %84, float %2, float %3) #6
  %93 = tail call contract float @llvm.musa.fma.rte.f(float %85, float %2, float %3) #6
  %94 = tail call contract float @llvm.musa.fma.rte.f(float %86, float %2, float %3) #6
  %95 = tail call contract float @llvm.musa.fma.rte.f(float %87, float %2, float %3) #6
  %96 = tail call contract float @llvm.musa.fma.rte.f(float %88, float %2, float %3) #6
  %97 = tail call contract float @llvm.musa.fma.rte.f(float %89, float %2, float %3) #6
  %98 = tail call contract float @llvm.musa.fma.rte.f(float %90, float %2, float %3) #6
  %99 = tail call contract float @llvm.musa.fma.rte.f(float %91, float %2, float %3) #6
  %100 = tail call contract float @llvm.musa.fma.rte.f(float %92, float %2, float %3) #6
  %101 = tail call contract float @llvm.musa.fma.rte.f(float %93, float %2, float %3) #6
  %102 = tail call contract float @llvm.musa.fma.rte.f(float %94, float %2, float %3) #6
  %103 = tail call contract float @llvm.musa.fma.rte.f(float %95, float %2, float %3) #6
  %104 = tail call contract float @llvm.musa.fma.rte.f(float %96, float %2, float %3) #6
  %105 = tail call contract float @llvm.musa.fma.rte.f(float %97, float %2, float %3) #6
  %106 = tail call contract float @llvm.musa.fma.rte.f(float %98, float %2, float %3) #6
  %107 = tail call contract float @llvm.musa.fma.rte.f(float %99, float %2, float %3) #6
  %108 = tail call contract float @llvm.musa.fma.rte.f(float %100, float %2, float %3) #6
  %109 = tail call contract float @llvm.musa.fma.rte.f(float %101, float %2, float %3) #6
  %110 = tail call contract float @llvm.musa.fma.rte.f(float %102, float %2, float %3) #6
  %111 = tail call contract float @llvm.musa.fma.rte.f(float %103, float %2, float %3) #6
  %112 = tail call contract float @llvm.musa.fma.rte.f(float %104, float %2, float %3) #6
  %113 = tail call contract float @llvm.musa.fma.rte.f(float %105, float %2, float %3) #6
  %114 = tail call contract float @llvm.musa.fma.rte.f(float %106, float %2, float %3) #6
  %115 = tail call contract float @llvm.musa.fma.rte.f(float %107, float %2, float %3) #6
  %116 = tail call contract float @llvm.musa.fma.rte.f(float %108, float %2, float %3) #6
  %117 = tail call contract float @llvm.musa.fma.rte.f(float %109, float %2, float %3) #6
  %118 = tail call contract float @llvm.musa.fma.rte.f(float %110, float %2, float %3) #6
  %119 = tail call contract float @llvm.musa.fma.rte.f(float %111, float %2, float %3) #6
  %120 = tail call contract float @llvm.musa.fma.rte.f(float %112, float %2, float %3) #6
  %121 = tail call contract float @llvm.musa.fma.rte.f(float %113, float %2, float %3) #6
  %122 = tail call contract float @llvm.musa.fma.rte.f(float %114, float %2, float %3) #6
  %123 = tail call contract float @llvm.musa.fma.rte.f(float %115, float %2, float %3) #6
  %124 = tail call contract float @llvm.musa.fma.rte.f(float %116, float %2, float %3) #6
  %125 = tail call contract float @llvm.musa.fma.rte.f(float %117, float %2, float %3) #6
  %126 = tail call contract float @llvm.musa.fma.rte.f(float %118, float %2, float %3) #6
  %127 = tail call contract float @llvm.musa.fma.rte.f(float %119, float %2, float %3) #6
  %128 = tail call contract float @llvm.musa.fma.rte.f(float %120, float %2, float %3) #6
  %129 = tail call contract float @llvm.musa.fma.rte.f(float %121, float %2, float %3) #6
  %130 = tail call contract float @llvm.musa.fma.rte.f(float %122, float %2, float %3) #6
  %131 = tail call contract float @llvm.musa.fma.rte.f(float %123, float %2, float %3) #6
  %132 = tail call contract float @llvm.musa.fma.rte.f(float %124, float %2, float %3) #6
  %133 = tail call contract float @llvm.musa.fma.rte.f(float %125, float %2, float %3) #6
  %134 = tail call contract float @llvm.musa.fma.rte.f(float %126, float %2, float %3) #6
  %135 = tail call contract float @llvm.musa.fma.rte.f(float %127, float %2, float %3) #6
  %136 = tail call contract float @llvm.musa.fma.rte.f(float %128, float %2, float %3) #6
  %137 = tail call contract float @llvm.musa.fma.rte.f(float %129, float %2, float %3) #6
  %138 = tail call contract float @llvm.musa.fma.rte.f(float %130, float %2, float %3) #6
  %139 = tail call contract float @llvm.musa.fma.rte.f(float %131, float %2, float %3) #6
  %140 = tail call contract float @llvm.musa.fma.rte.f(float %132, float %2, float %3) #6
  %141 = tail call contract float @llvm.musa.fma.rte.f(float %133, float %2, float %3) #6
  %142 = tail call contract float @llvm.musa.fma.rte.f(float %134, float %2, float %3) #6
  %143 = tail call contract float @llvm.musa.fma.rte.f(float %135, float %2, float %3) #6
  %144 = tail call contract float @llvm.musa.fma.rte.f(float %136, float %2, float %3) #6
  %145 = tail call contract float @llvm.musa.fma.rte.f(float %137, float %2, float %3) #6
  %146 = tail call contract float @llvm.musa.fma.rte.f(float %138, float %2, float %3) #6
  %147 = tail call contract float @llvm.musa.fma.rte.f(float %139, float %2, float %3) #6
  %148 = tail call contract float @llvm.musa.fma.rte.f(float %140, float %2, float %3) #6
  %149 = tail call contract float @llvm.musa.fma.rte.f(float %141, float %2, float %3) #6
  %150 = tail call contract float @llvm.musa.fma.rte.f(float %142, float %2, float %3) #6
  %151 = tail call contract float @llvm.musa.fma.rte.f(float %143, float %2, float %3) #6
  %152 = tail call contract float @llvm.musa.fma.rte.f(float %144, float %2, float %3) #6
  %153 = tail call contract float @llvm.musa.fma.rte.f(float %145, float %2, float %3) #6
  %154 = tail call contract float @llvm.musa.fma.rte.f(float %146, float %2, float %3) #6
  %155 = tail call contract float @llvm.musa.fma.rte.f(float %147, float %2, float %3) #6
  %156 = tail call contract float @llvm.musa.fma.rte.f(float %148, float %2, float %3) #6
  %157 = tail call contract float @llvm.musa.fma.rte.f(float %149, float %2, float %3) #6
  %158 = tail call contract float @llvm.musa.fma.rte.f(float %150, float %2, float %3) #6
  %159 = tail call contract float @llvm.musa.fma.rte.f(float %151, float %2, float %3) #6
  %160 = tail call contract float @llvm.musa.fma.rte.f(float %152, float %2, float %3) #6
  %161 = tail call contract float @llvm.musa.fma.rte.f(float %153, float %2, float %3) #6
  %162 = tail call contract float @llvm.musa.fma.rte.f(float %154, float %2, float %3) #6
  %163 = tail call contract float @llvm.musa.fma.rte.f(float %155, float %2, float %3) #6
  %164 = tail call contract float @llvm.musa.fma.rte.f(float %156, float %2, float %3) #6
  %165 = tail call contract float @llvm.musa.fma.rte.f(float %157, float %2, float %3) #6
  %166 = tail call contract float @llvm.musa.fma.rte.f(float %158, float %2, float %3) #6
  %167 = tail call contract float @llvm.musa.fma.rte.f(float %159, float %2, float %3) #6
  %168 = tail call contract float @llvm.musa.fma.rte.f(float %160, float %2, float %3) #6
  %169 = tail call contract float @llvm.musa.fma.rte.f(float %161, float %2, float %3) #6
  %170 = tail call contract float @llvm.musa.fma.rte.f(float %162, float %2, float %3) #6
  %171 = tail call contract float @llvm.musa.fma.rte.f(float %163, float %2, float %3) #6
  %172 = tail call contract float @llvm.musa.fma.rte.f(float %164, float %2, float %3) #6
  %173 = tail call contract float @llvm.musa.fma.rte.f(float %165, float %2, float %3) #6
  %174 = tail call contract float @llvm.musa.fma.rte.f(float %166, float %2, float %3) #6
  %175 = tail call contract float @llvm.musa.fma.rte.f(float %167, float %2, float %3) #6
  %176 = tail call contract float @llvm.musa.fma.rte.f(float %168, float %2, float %3) #6
  %177 = tail call contract float @llvm.musa.fma.rte.f(float %169, float %2, float %3) #6
  %178 = tail call contract float @llvm.musa.fma.rte.f(float %170, float %2, float %3) #6
  %179 = tail call contract float @llvm.musa.fma.rte.f(float %171, float %2, float %3) #6
  %180 = tail call contract float @llvm.musa.fma.rte.f(float %172, float %2, float %3) #6
  %181 = tail call contract float @llvm.musa.fma.rte.f(float %173, float %2, float %3) #6
  %182 = tail call contract float @llvm.musa.fma.rte.f(float %174, float %2, float %3) #6
  %183 = tail call contract float @llvm.musa.fma.rte.f(float %175, float %2, float %3) #6
  %184 = tail call contract float @llvm.musa.fma.rte.f(float %176, float %2, float %3) #6
  %185 = tail call contract float @llvm.musa.fma.rte.f(float %177, float %2, float %3) #6
  %186 = tail call contract float @llvm.musa.fma.rte.f(float %178, float %2, float %3) #6
  %187 = tail call contract float @llvm.musa.fma.rte.f(float %179, float %2, float %3) #6
  %188 = tail call contract float @llvm.musa.fma.rte.f(float %180, float %2, float %3) #6
  %189 = tail call contract float @llvm.musa.fma.rte.f(float %181, float %2, float %3) #6
  %190 = tail call contract float @llvm.musa.fma.rte.f(float %182, float %2, float %3) #6
  %191 = tail call contract float @llvm.musa.fma.rte.f(float %183, float %2, float %3) #6
  %192 = tail call contract float @llvm.musa.fma.rte.f(float %184, float %2, float %3) #6
  %193 = tail call contract float @llvm.musa.fma.rte.f(float %185, float %2, float %3) #6
  %194 = tail call contract float @llvm.musa.fma.rte.f(float %186, float %2, float %3) #6
  %195 = tail call contract float @llvm.musa.fma.rte.f(float %187, float %2, float %3) #6
  %196 = tail call contract float @llvm.musa.fma.rte.f(float %188, float %2, float %3) #6
  %197 = tail call contract float @llvm.musa.fma.rte.f(float %189, float %2, float %3) #6
  %198 = tail call contract float @llvm.musa.fma.rte.f(float %190, float %2, float %3) #6
  %199 = tail call contract float @llvm.musa.fma.rte.f(float %191, float %2, float %3) #6
  %200 = tail call contract float @llvm.musa.fma.rte.f(float %192, float %2, float %3) #6
  %201 = tail call contract float @llvm.musa.fma.rte.f(float %193, float %2, float %3) #6
  %202 = tail call contract float @llvm.musa.fma.rte.f(float %194, float %2, float %3) #6
  %203 = tail call contract float @llvm.musa.fma.rte.f(float %195, float %2, float %3) #6
  %204 = tail call contract float @llvm.musa.fma.rte.f(float %196, float %2, float %3) #6
  %205 = tail call contract float @llvm.musa.fma.rte.f(float %197, float %2, float %3) #6
  %206 = tail call contract float @llvm.musa.fma.rte.f(float %198, float %2, float %3) #6
  %207 = tail call contract float @llvm.musa.fma.rte.f(float %199, float %2, float %3) #6
  %208 = tail call contract float @llvm.musa.fma.rte.f(float %200, float %2, float %3) #6
  %209 = tail call contract float @llvm.musa.fma.rte.f(float %201, float %2, float %3) #6
  %210 = tail call contract float @llvm.musa.fma.rte.f(float %202, float %2, float %3) #6
  %211 = tail call contract float @llvm.musa.fma.rte.f(float %203, float %2, float %3) #6
  %212 = tail call contract float @llvm.musa.fma.rte.f(float %204, float %2, float %3) #6
  %213 = tail call contract float @llvm.musa.fma.rte.f(float %205, float %2, float %3) #6
  %214 = tail call contract float @llvm.musa.fma.rte.f(float %206, float %2, float %3) #6
  %215 = tail call contract float @llvm.musa.fma.rte.f(float %207, float %2, float %3) #6
  %216 = tail call contract float @llvm.musa.fma.rte.f(float %208, float %2, float %3) #6
  %217 = tail call contract float @llvm.musa.fma.rte.f(float %209, float %2, float %3) #6
  %218 = tail call contract float @llvm.musa.fma.rte.f(float %210, float %2, float %3) #6
  %219 = tail call contract float @llvm.musa.fma.rte.f(float %211, float %2, float %3) #6
  %220 = tail call contract float @llvm.musa.fma.rte.f(float %212, float %2, float %3) #6
  %221 = tail call contract float @llvm.musa.fma.rte.f(float %213, float %2, float %3) #6
  %222 = tail call contract float @llvm.musa.fma.rte.f(float %214, float %2, float %3) #6
  %223 = tail call contract float @llvm.musa.fma.rte.f(float %215, float %2, float %3) #6
  %224 = tail call contract float @llvm.musa.fma.rte.f(float %216, float %2, float %3) #6
  %225 = tail call contract float @llvm.musa.fma.rte.f(float %217, float %2, float %3) #6
  %226 = tail call contract float @llvm.musa.fma.rte.f(float %218, float %2, float %3) #6
  %227 = tail call contract float @llvm.musa.fma.rte.f(float %219, float %2, float %3) #6
  %228 = tail call contract float @llvm.musa.fma.rte.f(float %220, float %2, float %3) #6
  %229 = tail call contract float @llvm.musa.fma.rte.f(float %221, float %2, float %3) #6
  %230 = tail call contract float @llvm.musa.fma.rte.f(float %222, float %2, float %3) #6
  %231 = tail call contract float @llvm.musa.fma.rte.f(float %223, float %2, float %3) #6
  %232 = tail call contract float @llvm.musa.fma.rte.f(float %224, float %2, float %3) #6
  %233 = tail call contract float @llvm.musa.fma.rte.f(float %225, float %2, float %3) #6
  %234 = tail call contract float @llvm.musa.fma.rte.f(float %226, float %2, float %3) #6
  %235 = tail call contract float @llvm.musa.fma.rte.f(float %227, float %2, float %3) #6
  %236 = tail call contract float @llvm.musa.fma.rte.f(float %228, float %2, float %3) #6
  %237 = tail call contract float @llvm.musa.fma.rte.f(float %229, float %2, float %3) #6
  %238 = tail call contract float @llvm.musa.fma.rte.f(float %230, float %2, float %3) #6
  %239 = tail call contract float @llvm.musa.fma.rte.f(float %231, float %2, float %3) #6
  %240 = tail call contract float @llvm.musa.fma.rte.f(float %232, float %2, float %3) #6
  %241 = tail call contract float @llvm.musa.fma.rte.f(float %233, float %2, float %3) #6
  %242 = tail call contract float @llvm.musa.fma.rte.f(float %234, float %2, float %3) #6
  %243 = tail call contract float @llvm.musa.fma.rte.f(float %235, float %2, float %3) #6
  %244 = tail call contract float @llvm.musa.fma.rte.f(float %236, float %2, float %3) #6
  %245 = tail call contract float @llvm.musa.fma.rte.f(float %237, float %2, float %3) #6
  %246 = tail call contract float @llvm.musa.fma.rte.f(float %238, float %2, float %3) #6
  %247 = tail call contract float @llvm.musa.fma.rte.f(float %239, float %2, float %3) #6
  %248 = tail call contract float @llvm.musa.fma.rte.f(float %240, float %2, float %3) #6
  %249 = tail call contract float @llvm.musa.fma.rte.f(float %241, float %2, float %3) #6
  %250 = tail call contract float @llvm.musa.fma.rte.f(float %242, float %2, float %3) #6
  %251 = tail call contract float @llvm.musa.fma.rte.f(float %243, float %2, float %3) #6
  %252 = tail call contract float @llvm.musa.fma.rte.f(float %244, float %2, float %3) #6
  %253 = tail call contract float @llvm.musa.fma.rte.f(float %245, float %2, float %3) #6
  %254 = tail call contract float @llvm.musa.fma.rte.f(float %246, float %2, float %3) #6
  %255 = tail call contract float @llvm.musa.fma.rte.f(float %247, float %2, float %3) #6
  %256 = tail call contract float @llvm.musa.fma.rte.f(float %248, float %2, float %3) #6
  %257 = tail call contract float @llvm.musa.fma.rte.f(float %249, float %2, float %3) #6
  %258 = tail call contract float @llvm.musa.fma.rte.f(float %250, float %2, float %3) #6
  %259 = tail call contract float @llvm.musa.fma.rte.f(float %251, float %2, float %3) #6
  %260 = tail call contract float @llvm.musa.fma.rte.f(float %252, float %2, float %3) #6
  %261 = tail call contract float @llvm.musa.fma.rte.f(float %253, float %2, float %3) #6
  %262 = tail call contract float @llvm.musa.fma.rte.f(float %254, float %2, float %3) #6
  %263 = tail call contract float @llvm.musa.fma.rte.f(float %255, float %2, float %3) #6
  %264 = tail call contract float @llvm.musa.fma.rte.f(float %256, float %2, float %3) #6
  %265 = tail call contract float @llvm.musa.fma.rte.f(float %257, float %2, float %3) #6
  %266 = tail call contract float @llvm.musa.fma.rte.f(float %258, float %2, float %3) #6
  %267 = tail call contract float @llvm.musa.fma.rte.f(float %259, float %2, float %3) #6
  %268 = tail call contract float @llvm.musa.fma.rte.f(float %260, float %2, float %3) #6
  %269 = tail call contract float @llvm.musa.fma.rte.f(float %261, float %2, float %3) #6
  %270 = tail call contract float @llvm.musa.fma.rte.f(float %262, float %2, float %3) #6
  %271 = tail call contract float @llvm.musa.fma.rte.f(float %263, float %2, float %3) #6
  %272 = tail call contract float @llvm.musa.fma.rte.f(float %264, float %2, float %3) #6
  %273 = tail call contract float @llvm.musa.fma.rte.f(float %265, float %2, float %3) #6
  %274 = tail call contract float @llvm.musa.fma.rte.f(float %266, float %2, float %3) #6
  %275 = tail call contract float @llvm.musa.fma.rte.f(float %267, float %2, float %3) #6
  %276 = tail call contract float @llvm.musa.fma.rte.f(float %268, float %2, float %3) #6
  %277 = tail call contract float @llvm.musa.fma.rte.f(float %269, float %2, float %3) #6
  %278 = tail call contract float @llvm.musa.fma.rte.f(float %270, float %2, float %3) #6
  %279 = tail call contract float @llvm.musa.fma.rte.f(float %271, float %2, float %3) #6
  %280 = tail call contract float @llvm.musa.fma.rte.f(float %272, float %2, float %3) #6
  %281 = tail call contract float @llvm.musa.fma.rte.f(float %273, float %2, float %3) #6
  %282 = tail call contract float @llvm.musa.fma.rte.f(float %274, float %2, float %3) #6
  %283 = tail call contract float @llvm.musa.fma.rte.f(float %275, float %2, float %3) #6
  %284 = tail call contract float @llvm.musa.fma.rte.f(float %276, float %2, float %3) #6
  %285 = tail call contract float @llvm.musa.fma.rte.f(float %277, float %2, float %3) #6
  %286 = tail call contract float @llvm.musa.fma.rte.f(float %278, float %2, float %3) #6
  %287 = tail call contract float @llvm.musa.fma.rte.f(float %279, float %2, float %3) #6
  %288 = tail call contract float @llvm.musa.fma.rte.f(float %280, float %2, float %3) #6
  %289 = tail call contract float @llvm.musa.fma.rte.f(float %281, float %2, float %3) #6
  %290 = tail call contract float @llvm.musa.fma.rte.f(float %282, float %2, float %3) #6
  %291 = tail call contract float @llvm.musa.fma.rte.f(float %283, float %2, float %3) #6
  %292 = tail call contract float @llvm.musa.fma.rte.f(float %284, float %2, float %3) #6
  %293 = tail call contract float @llvm.musa.fma.rte.f(float %285, float %2, float %3) #6
  %294 = tail call contract float @llvm.musa.fma.rte.f(float %286, float %2, float %3) #6
  %295 = tail call contract float @llvm.musa.fma.rte.f(float %287, float %2, float %3) #6
  %296 = tail call contract float @llvm.musa.fma.rte.f(float %288, float %2, float %3) #6
  %297 = tail call contract float @llvm.musa.fma.rte.f(float %289, float %2, float %3) #6
  %298 = tail call contract float @llvm.musa.fma.rte.f(float %290, float %2, float %3) #6
  %299 = tail call contract float @llvm.musa.fma.rte.f(float %291, float %2, float %3) #6
  %300 = tail call contract float @llvm.musa.fma.rte.f(float %292, float %2, float %3) #6
  %301 = tail call contract float @llvm.musa.fma.rte.f(float %293, float %2, float %3) #6
  %302 = tail call contract float @llvm.musa.fma.rte.f(float %294, float %2, float %3) #6
  %303 = tail call contract float @llvm.musa.fma.rte.f(float %295, float %2, float %3) #6
  %304 = tail call contract float @llvm.musa.fma.rte.f(float %296, float %2, float %3) #6
  %305 = tail call contract float @llvm.musa.fma.rte.f(float %297, float %2, float %3) #6
  %306 = tail call contract float @llvm.musa.fma.rte.f(float %298, float %2, float %3) #6
  %307 = tail call contract float @llvm.musa.fma.rte.f(float %299, float %2, float %3) #6
  %308 = tail call contract float @llvm.musa.fma.rte.f(float %300, float %2, float %3) #6
  %309 = tail call contract float @llvm.musa.fma.rte.f(float %301, float %2, float %3) #6
  %310 = tail call contract float @llvm.musa.fma.rte.f(float %302, float %2, float %3) #6
  %311 = insertelement <8 x float> poison, float %310, i64 0
  %312 = tail call contract float @llvm.musa.fma.rte.f(float %303, float %2, float %3) #6
  %313 = insertelement <8 x float> %311, float %312, i64 1
  %314 = tail call contract float @llvm.musa.fma.rte.f(float %304, float %2, float %3) #6
  %315 = insertelement <8 x float> %313, float %314, i64 2
  %316 = tail call contract float @llvm.musa.fma.rte.f(float %305, float %2, float %3) #6
  %317 = insertelement <8 x float> %315, float %316, i64 3
  %318 = tail call contract float @llvm.musa.fma.rte.f(float %306, float %2, float %3) #6
  %319 = insertelement <8 x float> %317, float %318, i64 4
  %320 = tail call contract float @llvm.musa.fma.rte.f(float %307, float %2, float %3) #6
  %321 = insertelement <8 x float> %319, float %320, i64 5
  %322 = tail call contract float @llvm.musa.fma.rte.f(float %308, float %2, float %3) #6
  %323 = insertelement <8 x float> %321, float %322, i64 6
  %324 = tail call contract float @llvm.musa.fma.rte.f(float %309, float %2, float %3) #6
  %325 = insertelement <8 x float> %323, float %324, i64 7
  %326 = add nuw nsw i32 %52, 1
  %327 = icmp slt i32 %326, %1
  br i1 %327, label %51, label %328, !llvm.loop !26

328:                                              ; preds = %51, %4
  %329 = phi <8 x float> [ %49, %4 ], [ %325, %51 ]
  %330 = zext i32 %9 to i64
  %331 = shl nuw nsw i64 %330, 3
  %332 = extractelement <8 x float> %329, i64 0
  %333 = getelementptr inbounds float, float* %0, i64 %331
  store float %332, float* %333, align 4, !tbaa !28
  %334 = extractelement <8 x float> %329, i64 1
  %335 = or i64 %331, 1
  %336 = getelementptr inbounds float, float* %0, i64 %335
  store float %334, float* %336, align 4, !tbaa !28
  %337 = extractelement <8 x float> %329, i64 2
  %338 = or i64 %331, 2
  %339 = getelementptr inbounds float, float* %0, i64 %338
  store float %337, float* %339, align 4, !tbaa !28
  %340 = extractelement <8 x float> %329, i64 3
  %341 = or i64 %331, 3
  %342 = getelementptr inbounds float, float* %0, i64 %341
  store float %340, float* %342, align 4, !tbaa !28
  %343 = extractelement <8 x float> %329, i64 4
  %344 = or i64 %331, 4
  %345 = getelementptr inbounds float, float* %0, i64 %344
  store float %343, float* %345, align 4, !tbaa !28
  %346 = extractelement <8 x float> %329, i64 5
  %347 = or i64 %331, 5
  %348 = getelementptr inbounds float, float* %0, i64 %347
  store float %346, float* %348, align 4, !tbaa !28
  %349 = extractelement <8 x float> %329, i64 6
  %350 = or i64 %331, 6
  %351 = getelementptr inbounds float, float* %0, i64 %350
  store float %349, float* %351, align 4, !tbaa !28
  %352 = extractelement <8 x float> %329, i64 7
  %353 = or i64 %331, 7
  %354 = getelementptr inbounds float, float* %0, i64 %353
  store float %352, float* %354, align 4, !tbaa !28
  ret void
}

; Function Attrs: nofree nosync nounwind readnone
declare float @llvm.musa.fma.rte.f(float, float, float) #4

attributes #0 = { convergent mustprogress nofree norecurse nounwind writeonly "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mp_31" "target-features"="+mp_31" }
attributes #1 = { convergent mustprogress nofree norecurse nounwind "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mp_31" "target-features"="+mp_31" }
attributes #2 = { convergent nofree norecurse nounwind "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="mp_31" "target-features"="+mp_31" }
attributes #3 = { convergent nofree nounwind readnone }
attributes #4 = { nofree nosync nounwind readnone }
attributes #5 = { mustprogress nofree nosync nounwind readnone speculatable willreturn }
attributes #6 = { nounwind }

!musa.annotations = !{!0, !1, !2, !3, !4, !5}
!llvm.module.flags = !{!6, !7}
!llvm.ident = !{!8}
!mt.printf.fmts = !{!9}

!0 = !{void (%struct.uint4*, %struct.uint4*, %struct.uint4*, i64)* @_Z17initialize_memoryP5uint4S0_S0_m, !"kernel", i32 1}
!1 = !{void (%struct.uint4*, %struct.uint4*, i64)* @_Z11memory_copyPK5uint4PS_m, !"kernel", i32 1}
!2 = !{void (%struct.uint4*, i64)* @_Z12memory_writeP5uint4m, !"kernel", i32 1}
!3 = !{void (%struct.uint4*, %struct.uint4*, i64)* @_Z11memory_readPK5uint4PS_m, !"kernel", i32 1}
!4 = !{void (%struct.uint4*, %struct.uint4*, %struct.uint4*, i64, float)* @_Z12memory_triadPK5uint4S1_PS_mf, !"kernel", i32 1}
!5 = !{void (float*, i32, float, float)* @_Z11compute_fmaI4FP32EvPNT_1TEiS2_S2_, !"kernel", i32 1}
!6 = !{i32 1, !"wchar_size", i32 4}
!7 = !{i32 7, !"frame-pointer", i32 2}
!8 = !{!"clang version 14.0.0 (git@sh-code.mthreads.com:sw/mtcc.git 23a614460b10fbb6ac5be3673102c6d8524d969a)\0Amcc version 4.3.5"}
!9 = !{!"0:"}
!10 = !{i32 0}
!11 = !{i64 0, i64 4, !12, i64 4, i64 4, !12, i64 8, i64 4, !12, i64 12, i64 4, !12}
!12 = !{!13, !13, i64 0}
!13 = !{!"int", !14, i64 0}
!14 = !{!"omnipotent char", !15, i64 0}
!15 = !{!"Simple C++ TBAA"}
!16 = !{i64 0, i64 4, !12, i64 4, i64 4, !12, i64 8, i64 4, !12}
!17 = !{i64 0, i64 4, !12, i64 4, i64 4, !12}
!18 = !{i64 0, i64 4, !12}
!19 = distinct !{!19, !20}
!20 = !{!"llvm.loop.mustprogress"}
!21 = distinct !{!21, !20}
!22 = distinct !{!22, !20}
!23 = distinct !{!23, !20}
!24 = distinct !{!24, !20}
!25 = !{i32 256}
!26 = distinct !{!26, !20, !27}
!27 = !{!"llvm.loop.unroll.count", i32 1}
!28 = !{!29, !29, i64 0}
!29 = !{!"float", !14, i64 0}
