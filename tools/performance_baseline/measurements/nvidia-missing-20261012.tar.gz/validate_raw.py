#!/usr/bin/env python3
"""Strict CPU-only audit of one 371-case NVIDIA missing-case collection.

Usage: python /tmp/validate_nvidia_missing_raw.py RUN_DIR [--output SUMMARY.json]
Exit 0: all 371 measurements pass every integrity check.
Exit 1: failed measurements, missing cases or integrity violations.
No CUDA imports, subprocess execution, or repository writes are performed.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import sys

DEFAULT_REPORT = Path('/home/wangbingjie/FlagDNN/docs/nvidia-performance-missing-cases-20261012.md')
GROUP_COUNTS = {'core': 291, 'aux': 80}
BITS = {'fp32': 32, 'fp16': 16, 'bfloat16': 16, 'int32': 32, 'bool': 1, 'boolean_bitpacked': 1}
TIMING_KEYS = ('method', 'unit', 'warmup_iterations', 'sample_count', 'iterations_per_sample', 'graph_warmup_launches', 'percentile_method')
CORE_PHASES = ('before_timing', 'after_timing', 'after_reset_graph_replay')
AUX_PHASES = ('before_timing', 'after_timing', 'after_reset_replay')

class Audit:
    def __init__(self):
        self.failures = []
        self.warnings = []
        self.checked_assertions = 0
    def check(self, condition, where, message, category='integrity'):
        self.checked_assertions += 1
        if not condition:
            self.failures.append({'category': category, 'location': where, 'message': message})
        return bool(condition)
    def eq(self, actual, expected, where):
        return self.check(actual == expected, where, f'expected {expected!r}; got {actual!r}')
    def finite(self, value, where, positive=False):
        return self.check(isinstance(value, (int, float)) and not isinstance(value, bool)
                          and math.isfinite(value) and (value > 0 if positive else value >= 0),
                          where, f'expected finite {"positive" if positive else "nonnegative"} number; got {value!r}')
    def close(self, actual, expected, where):
        return self.check(isinstance(actual, (int, float)) and not isinstance(actual, bool)
                          and math.isfinite(actual) and math.isclose(actual, expected, rel_tol=2e-10, abs_tol=1e-10),
                          where, f'expected {expected!r} within JSON serialization precision; got {actual!r}')


def unique_object(pairs):
    result = {}
    for k, v in pairs:
        if k in result:
            raise ValueError(f'duplicate JSON field {k!r}')
        result[k] = v
    return result


def strict_loads(text):
    def bad_constant(value):
        raise ValueError(f'nonstandard/nonfinite JSON number {value}')
    return json.loads(text, object_pairs_hook=unique_object, parse_constant=bad_constant)


def load_json(path, a):
    try:
        value = strict_loads(path.read_text())
        a.check(isinstance(value, dict), str(path), 'JSON root must be an object')
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError) as exc:
        a.check(False, str(path), str(exc))
        return {}


def load_rows(path, a):
    try:
        lines = path.read_text().splitlines()
    except OSError as exc:
        a.check(False, str(path), str(exc))
        return []
    rows = []
    for n, line in enumerate(lines, 1):
        if not line.strip():
            a.check(False, f'{path}:{n}', 'blank JSONL line')
            continue
        try:
            row = strict_loads(line)
            if a.check(isinstance(row, dict), f'{path}:{n}', 'row must be object'):
                rows.append(row)
        except ValueError as exc:
            a.check(False, f'{path}:{n}', str(exc))
    return rows


def report_cases(path, a):
    try:
        text = path.read_text().split('## 附录一', 1)[1].split('## 附录二', 1)[0]
        result = [(op, name) for op, count, block in re.findall(
            r'### (\w+) (\d+) 个\s+```text\n(.*?)```', text, re.S)
                  for name in block.splitlines() if name]
        a.eq(len(result), 371, 'report.case_count')
        a.eq(len(set(result)), 371, 'report.unique_case_count')
        a.eq(len({x[0] for x in result}), 22, 'report.operator_count')
        return set(result)
    except (OSError, IndexError, ValueError) as exc:
        a.check(False, str(path), str(exc))
        return set()


def key(row):
    return (row.get('op'), row.get('case_name'))


def index_rows(rows, where, a):
    result = {}
    for row in rows:
        k = key(row)
        a.check(all(isinstance(x, str) and x for x in k), where, f'invalid case key {k!r}')
        a.check(k not in result, where, f'duplicate case key {k!r}')
        result[k] = row
    return result


def compare_tree(actual, expected, where, a):
    if isinstance(expected, dict):
        if not a.check(isinstance(actual, dict), where, 'metadata object missing or wrong type'):
            return
        a.eq(set(actual), set(expected), where + '.keys')
        for k, value in expected.items():
            if k in actual:
                compare_tree(actual[k], value, where + '.' + k, a)
    elif isinstance(expected, list):
        if not a.check(isinstance(actual, list), where, 'metadata list missing or wrong type'):
            return
        a.eq(len(actual), len(expected), where + '.length')
        for i, (value, wanted) in enumerate(zip(actual, expected)):
            compare_tree(value, wanted, f'{where}[{i}]', a)
    else:
        a.eq(actual, expected, where)


def product(shape):
    return math.prod(shape)


def span(shape, strides):
    return 1 + sum((d - 1) * s for d, s in zip(shape, strides))


def contiguous(shape):
    result = [1] * len(shape)
    for i in range(len(shape) - 2, -1, -1):
        result[i] = result[i + 1] * shape[i + 1]
    return result


def byte_count(t, reference=True):
    shape = t.get('reference_shape', t['shape']) if reference else t['shape']
    strides = t['reference_strides'] if reference else t['strides']
    return (span(shape, strides) * BITS[t['dtype']] + 7) // 8


def check_tensor(t, group, where, a):
    a.check(isinstance(t.get('uid'), int) and t['uid'] > 0, where + '.uid', 'positive integer UID required')
    shape, strides = t.get('shape'), t.get('strides')
    if not a.check(isinstance(shape, list) and isinstance(strides, list) and len(shape) == len(strides), where, 'shape/strides rank mismatch'):
        return
    a.check(all(isinstance(x, int) and x > 0 for x in shape + strides), where, 'dimensions/strides must be positive integers')
    a.check(t.get('dtype') in BITS, where + '.dtype', 'unexpected dtype')
    a.check(t.get('role') in ('input', 'output', 'intermediate'), where + '.role', 'invalid role')
    a.check(isinstance(t.get('binding_byte_offset'), int) and t['binding_byte_offset'] >= 0, where + '.binding_byte_offset', 'nonnegative integer offset required')
    a.eq(t.get('logical_elements'), product(shape), where + '.logical_elements')
    a.eq(t.get('native_strides'), t.get('reference_strides'), where + '.native_vs_reference_strides')
    a.check(isinstance(t.get('reference_strides'), list) and len(t['reference_strides']) == len(shape), where, 'reference strides rank mismatch')
    if t.get('dtype') not in BITS or not isinstance(t.get('reference_strides'), list):
        return
    a.eq(t.get('reference_storage_bytes'), byte_count(t), where + '.reference_storage_bytes')
    if group == 'core':
        a.eq(t.get('storage_bytes'), byte_count(t, False), where + '.storage_bytes')
        a.eq(t.get('reference_shape'), shape, where + '.reference_shape')
        a.eq(t.get('reference_layout_conversion_timed'), False, where + '.reference_layout_conversion_timed')
        a.eq(t.get('reference_layout_conversion'), strides != t['reference_strides'], where + '.reference_layout_conversion')
    else:
        a.eq(t.get('storage_elements'), span(shape, strides), where + '.storage_elements')
        a.eq(t.get('reference_strides'), strides, where + '.reference_strides')
        a.eq(t.get('reference_storage_bits'), BITS[t['dtype']], where + '.reference_storage_bits')
        a.eq(t.get('logical_storage_bits'), 8 if BITS[t['dtype']] == 1 else BITS[t['dtype']], where + '.logical_storage_bits')
    if BITS[t['dtype']] == 1:
        a.eq(t.get('boolean_encoding'), 'bitpacked', where + '.boolean_encoding')
        a.eq(product(shape) % 8, 0, where + '.boolean_whole_bytes')
        a.eq(span(shape, strides), product(shape), where + '.boolean_dense')


def check_semantics(row, group, where, a):
    tensors = row.get('tensors', [])
    a.check(isinstance(tensors, list) and bool(tensors), where + '.tensors', 'nonempty tensor list required')
    if not isinstance(tensors, list): return
    for i, t in enumerate(tensors): check_tensor(t, group, f'{where}.tensors[{i}]', a)
    uids = [t.get('uid') for t in tensors]
    a.eq(len(set(uids)), len(uids), where + '.unique_tensor_uids')
    inputs = [t for t in tensors if t.get('role') == 'input']
    outputs = [t for t in tensors if t.get('role') == 'output']
    intermediates = [t for t in tensors if t.get('role') == 'intermediate']
    if group == 'core':
        a.eq(row.get('input_count'), len(inputs), where + '.input_count')
        a.eq(row.get('output_count'), len(outputs), where + '.output_count')
        a.eq(len(row.get('input_domains', [])), len(inputs), where + '.input_domains.length')
        a.eq(row.get('reference_uses_quantized_inputs'), True, where + '.reference_uses_quantized_inputs')
        a.eq(row.get('input_generator'), 'backends/nvidia/validation/benchmark/runner.cpp::make_input', where + '.input_generator')
        a.eq(row.get('catalog_source'), 'benchmark/test_' + row['op'] + '.cpp', where + '.catalog_source')
        a.eq(row.get('allocation_guard_bytes_per_side'), 256, where + '.guard_bytes')
    else:
        a.eq(len(outputs), 1, where + '.output_count')
        a.eq(intermediates, [], where + '.intermediate_roles')
        a.eq(row.get('intermediate_tensors'), [], where + '.intermediate_tensors')
        a.eq(row.get('guard_prefix_bytes'), 256, where + '.guard_prefix_bytes')
        a.eq(row.get('guard_suffix_bytes'), 256, where + '.guard_suffix_bytes')
        a.eq(row.get('reference_layout_conversion'), False, where + '.reference_layout_conversion')
        expected_source = 'tests/common/reduction.cpp' if row['op'] == 'reduction' else 'tests/common/pointwise.cpp'
        a.eq(row.get('catalog_source'), expected_source, where + '.catalog_source')
        a.check(bool(re.fullmatch(r'[0-9a-f]{40}', row.get('source_revision', ''))), where + '.source_revision', 'full git revision required')
        rules = row.get('inputgen', {}).get('inputs', [])
        a.eq(len(rules), len(inputs), where + '.inputgen.count')
        a.eq(row.get('inputgen', {}).get('source'), 'backends/hygon/validation/benchmark/runner.cpp:make_input', where + '.inputgen.source')
        for i, (rule, t) in enumerate(zip(rules, inputs)):
            a.eq(rule.get('uid'), t['uid'], f'{where}.inputgen[{i}].uid')
            a.eq(rule.get('input_index'), i, f'{where}.inputgen[{i}].index')
            a.eq(rule.get('domain'), 'logical' if row['op'].startswith('logical_') else 'real', f'{where}.inputgen[{i}].domain')
    if row['op'] == 'batchnorm':
        a.eq(len(inputs), 5, where + '.batchnorm.inputs')
        a.eq(len(outputs), 5, where + '.batchnorm.outputs')
        if len(inputs) == len(outputs) == 5:
            dtype = inputs[0]['dtype']
            a.check(dtype in ('fp16', 'bfloat16'), where, 'BatchNorm dtype must be FP16/BF16')
            a.eq([t['dtype'] for t in inputs], [dtype, dtype, dtype, 'fp32', 'fp32'], where + '.batchnorm.input_dtypes')
            a.eq([t['dtype'] for t in outputs], [dtype, 'fp32', 'fp32', 'fp32', 'fp32'], where + '.batchnorm.output_dtypes')
            a.eq([t['semantic_role'] for t in inputs + outputs], ['x', 'scale', 'bias', 'previous_running_mean', 'previous_running_variance', 'y', 'saved_mean', 'saved_inverse_variance', 'next_running_mean', 'next_running_variance'], where + '.batchnorm.roles')
            shape = inputs[0]['shape']
            if len(shape) == 4:
                n, c, h, w = shape
                for t in (inputs[0], outputs[0]):
                    a.eq(t['shape'], shape, where + '.batchnorm.xy_shape')
                    a.eq(t['strides'], contiguous(shape), where + '.batchnorm.logical_nchw')
                    a.eq(t['reference_strides'], [c*h*w, 1, w*c, c], where + '.batchnorm.reference_nhwc')
                for t in inputs[1:] + outputs[1:]: a.eq(t['shape'], [1, c, 1, 1], where + '.batchnorm.channel_shape')
            a.eq(row['attributes'].get('epsilon'), 0.001, where + '.batchnorm.epsilon')
            a.eq(row['attributes'].get('momentum'), 0.1, where + '.batchnorm.momentum')
            a.eq(row.get('input_domains'), [0, 0, 0, 0, 1], where + '.batchnorm.input_domains')
    elif row['op'] == 'reduction' and inputs and outputs:
        a.eq([inputs[0]['binding_byte_offset'], outputs[0]['binding_byte_offset']], [16, 32], where + '.reduction.offsets')
        a.eq(outputs[0]['dtype'], 'fp32', where + '.reduction.output_dtype')
        attrs = row['attributes']; shape = list(inputs[0]['shape']); axis = attrs['axis'] % len(shape)
        if attrs['keep_dimensions']: shape[axis] = 1
        else: shape.pop(axis)
        a.eq(outputs[0]['shape'], shape, where + '.reduction.output_shape')
        if inputs[0]['dtype'] == 'bfloat16':
            a.eq(len(inputs[0]['shape']), 2, where + '.reduction.bf16_rank')
            a.eq(attrs['mode_name'], 'sum', where + '.reduction.bf16_mode')
        else:
            a.eq(inputs[0]['dtype'], 'fp16', where + '.reduction.input_dtype')
            a.check((inputs[0]['shape'], attrs['axis']) in [([3,5,7],1), ([2,7,5,3],2)], where + '.reduction.middle_axis', 'unexpected FP16 reduction shape/axis')
    elif row['op'] == 'add_square':
        a.eq(len(inputs), 2, where + '.add_square.inputs'); a.eq(len(intermediates), 1, where + '.add_square.intermediate_count')
        nodes = row.get('graph_nodes', []); a.eq(len(nodes), 2, where + '.add_square.nodes')
        if len(inputs) == 2 and len(intermediates) == 1 and len(outputs) == 1 and len(nodes) == 2:
            a.eq(nodes[0]['input_uids'], [inputs[1]['uid']] * 2, where + '.add_square.square_inputs')
            a.eq(nodes[0]['output_uid'], intermediates[0]['uid'], where + '.add_square.square_output')
            a.eq(nodes[1]['input_uids'], [inputs[0]['uid'], intermediates[0]['uid']], where + '.add_square.add_inputs')
            a.eq(nodes[1]['output_uid'], outputs[0]['uid'], where + '.add_square.output')
            for t in tensors:
                a.eq(t['dtype'], 'bfloat16', where + '.add_square.dtype')
                a.eq(t['shape'], inputs[0]['shape'], where + '.add_square.shape')
                a.eq(t['strides'], inputs[0]['strides'], where + '.add_square.strides')
                a.eq(t.get('reference_descriptor_shape'), [1, product(t['shape']), 1, 1], where + '.add_square.flatten_shape')
    elif row['op'] == 'scale':
        a.eq(len(inputs), 2, where + '.scale.inputs')
        if len(inputs) == 2: a.eq(inputs[0]['shape'], inputs[1]['shape'], where + '.scale.equal_shapes')
    return inputs, outputs


def check_metadata(row, catalog, group, where, a):
    excluded = {'schema_version', 'status', 'timing', 'absolute_tolerance', 'relative_tolerance'} if group == 'core' else {'status', 'stage', 'reason', 'build_us', 'workspace_bytes', 'correctness', 'timing'}
    for field, expected in catalog.items():
        if field not in excluded:
            compare_tree(row.get(field), expected, where + '.metadata.' + field, a)
    for field in TIMING_KEYS:
        a.eq(row.get('timing', {}).get(field), catalog.get('timing', {}).get(field), where + '.metadata.timing.' + field)
    if group == 'core' and isinstance(row.get('correctness'), dict):
        for field in ('absolute_tolerance', 'relative_tolerance'):
            a.eq(row['correctness'].get(field), catalog.get(field), where + '.correctness.' + field)
    elif group == 'aux' and isinstance(row.get('correctness'), dict):
        for field, expected in catalog.get('correctness', {}).items():
            if field not in {'status', 'checked_elements', 'phases'}:
                compare_tree(row['correctness'].get(field), expected, where + '.correctness.metadata.' + field, a)


def check_timing(row, group, where, a):
    t = row.get('timing', {})
    bn = row['op'] == 'batchnorm'
    expected = (5, 10, 20, 1) if bn else (10, 20, 50, 1)
    a.eq(tuple(t.get(k) for k in TIMING_KEYS[2:6]), expected, where + '.timing.configuration')
    a.eq(t.get('method'), 'cuda_events_over_cuda_graph' if group == 'core' else 'cuda_event_cuda_graph_batch', where + '.timing.method')
    a.eq(t.get('unit'), 'us', where + '.timing.unit')
    a.eq(t.get('percentile_method'), 'nearest_rank', where + '.timing.percentile_method')
    samples = t.get('samples_us'); batches = t.get('sample_batch_us' if group == 'core' else 'sample_batches_us')
    if not a.check(isinstance(samples, list) and isinstance(batches, list), where + '.timing', 'samples and raw batches must be lists'): return
    a.eq(len(samples), expected[1], where + '.timing.sample_count')
    a.eq(len(batches), expected[1], where + '.timing.batch_count')
    finite = True
    for i, value in enumerate(samples): finite = a.finite(value, f'{where}.samples[{i}]', True) and finite
    for i, value in enumerate(batches): finite = a.finite(value, f'{where}.batches[{i}]', True) and finite
    if not finite or not samples: return
    for i, (sample, batch) in enumerate(zip(samples, batches)): a.close(sample, batch / expected[2], f'{where}.timing.batch_division[{i}]')
    ordered = sorted(samples)
    for field, fraction in [('median_us', .5), ('p90_us', .9)]: a.close(t.get(field), ordered[math.ceil(fraction*len(ordered))-1], where + '.timing.' + field)
    if group == 'core':
        a.close(t.get('p95_us'), ordered[math.ceil(.95*len(ordered))-1], where + '.timing.p95_us')
        a.close(t.get('min_us'), ordered[0], where + '.timing.min_us')
        a.finite(t.get('warmup_total_us'), where + '.timing.warmup_total_us', True)


def check_correctness(row, group, inputs, outputs, where, a):
    c = row.get('correctness')
    if not a.check(isinstance(c, dict), where + '.correctness', 'PASS needs detailed correctness object'): return
    a.eq(c.get('status'), 'PASS', where + '.correctness.status')
    total = sum(product(t['shape']) for t in outputs)
    a.eq(c.get('total_elements'), total, where + '.correctness.total_elements')
    a.eq(c.get('checked_elements'), total, where + '.correctness.checked_elements')
    for k in ('absolute_tolerance', 'relative_tolerance'): a.finite(c.get(k), where + '.correctness.' + k)
    exact = row['op'] == 'identity' or row['op'].startswith('logical_')
    if group == 'core':
        a.eq(c.get('scope'), 'full', where + '.correctness.scope')
        a.eq(c.get('sample_indices'), [], where + '.correctness.sample_indices')
        a.eq(c.get('reference'), 'reference/cpu/benchmark.cpp::evaluate_benchmark', where + '.correctness.reference')
        phases = c.get('phases', {})
        if not a.check(isinstance(phases, dict), where + '.phases', 'core phases must be object'): return
        a.eq(set(phases), set(CORE_PHASES), where + '.phases.names')
        max_abs = max_rel = 0.0
        for name in CORE_PHASES:
            p = phases.get(name, {}); loc = where + '.phases.' + name
            a.eq(p.get('status'), 'PASS', loc + '.status'); a.eq(p.get('inputs_unchanged'), True, loc + '.inputs_unchanged')
            protected = sum(512 + t['binding_byte_offset'] + byte_count(t) for t in inputs)
            a.eq(p.get('input_bytes_checked'), protected, loc + '.input_bytes_checked')
            checked_outputs = p.get('outputs', [])
            a.eq([x.get('uid') for x in checked_outputs], [x['uid'] for x in outputs], loc + '.output_uids')
            for t, o in zip(outputs, checked_outputs):
                oloc = loc + '.output.' + str(t['uid']); count = product(t['shape'])
                a.eq(o.get('status'), 'PASS', oloc + '.status')
                a.eq(o.get('total_elements'), count, oloc + '.total_elements')
                a.eq(o.get('checked_elements'), count, oloc + '.checked_elements')
                a.eq(o.get('complete_write'), True, oloc + '.complete_write')
                padding_bytes = byte_count(t) - (count * BITS[t['dtype']] // 8)
                a.eq(o.get('protected_bytes_checked'), 512 + t['binding_byte_offset'] + padding_bytes, oloc + '.protected_bytes_checked')
                for field in ('max_abs_error', 'max_rel_error'): a.finite(o.get(field), oloc + '.' + field)
                if exact:
                    a.eq(o.get('max_abs_error'), 0, oloc + '.exact_abs'); a.eq(o.get('max_rel_error'), 0, oloc + '.exact_rel')
                max_abs = max(max_abs, o.get('max_abs_error', 0)); max_rel = max(max_rel, o.get('max_rel_error', 0))
        a.close(c.get('max_abs_error'), max_abs, where + '.correctness.max_abs_aggregate')
        a.close(c.get('max_rel_error'), max_rel, where + '.correctness.max_rel_aggregate')
    else:
        a.eq(c.get('scope'), 'bit_exact' if row['op'] == 'identity' else 'cpu_full', where + '.correctness.scope')
        phases = c.get('phases', [])
        if not a.check(isinstance(phases, list), where + '.phases', 'aux phases must be list'): return
        a.eq([x.get('phase') for x in phases], list(AUX_PHASES), where + '.phases.names')
        for p in phases:
            loc = where + '.phases.' + str(p.get('phase'))
            a.eq(p.get('status'), 'PASS', loc + '.status'); a.eq(p.get('checked_elements'), total, loc + '.checked_elements')
            a.eq(p.get('inputs_unchanged'), True, loc + '.inputs_unchanged'); a.eq(p.get('padding_and_boundaries_intact'), True, loc + '.guards')
            for field in ('maximum_absolute_error', 'maximum_relative_error'):
                a.finite(p.get(field), loc + '.' + field)
                if exact: a.eq(p.get(field), 0, loc + '.exact.' + field)


def check_row(row, catalog, group, a, require_process_metadata=True):
    where = group + ':' + str(row.get('case_name'))
    check_metadata(row, catalog, group, where, a)
    semantic = check_semantics(row, group, where, a)
    if semantic is None: return
    inputs, outputs = semantic
    if require_process_metadata:
        a.finite(row.get('wall_seconds'), where + '.wall_seconds')
        allowed = {'shared_cuda_context'} if group == 'core' else {'shared_process_per_case_primary_context', 'shared_cuda_context'}
        a.check(row.get('process_mode') in allowed, where + '.process_mode', 'missing/unexpected process mode')
    if row.get('status') != 'PASS':
        a.check(False, where, f"measurement status={row.get('status')!r}; stage={row.get('stage')!r}; reason={row.get('error') or row.get('reason')!r}", 'measurement')
        a.check(bool(row.get('error') or row.get('reason')), where + '.failure_reason', 'failed measurement must retain reason')
        a.check(row.get('stage') != 'complete', where + '.stage', 'failed measurement cannot be complete')
        for field in ('median_us', 'p90_us', 'p95_us', 'min_us', 'time_us'):
            a.check(field not in row.get('timing', {}) and field not in row, where + '.failed.' + field, 'failed measurement must not expose valid timing summary')
        return
    a.eq(row.get('stage'), 'complete', where + '.stage')
    a.check(not row.get('error') and not row.get('reason'), where + '.reason', 'PASS must have no error/reason')
    a.finite(row.get('build_us'), where + '.build_us')
    a.check(isinstance(row.get('workspace_bytes'), int) and row['workspace_bytes'] >= 0, where + '.workspace_bytes', 'workspace must be nonnegative integer')
    if group == 'core':
        a.eq(row.get('input_precision'), 0, where + '.input_precision')
        a.eq(row.get('reference_input_precision'), 0, where + '.reference_input_precision')
        a.eq(row.get('reference_quantizes_outputs'), True, where + '.reference_quantizes_outputs')
        a.eq(row.get('reference_tf32_rounding'), None, where + '.reference_tf32_rounding')
        a.check('H100' in row.get('device', ''), where + '.device', 'expected H100 device')
        a.check(bool(re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ', row.get('timestamp_utc', ''))), where + '.timestamp', 'UTC timestamp required')
        for field in ('cuda_driver', 'cuda_runtime', 'cudnn_version'): a.finite(row.get(field), where + '.' + field, True)
    check_correctness(row, group, inputs, outputs, where, a)
    check_timing(row, group, where, a)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_dir', type=Path)
    parser.add_argument('--report', type=Path, default=DEFAULT_REPORT)
    parser.add_argument('--output', type=Path, help='Optional JSON summary file; stdout always receives the JSON summary.')
    args = parser.parse_args(argv)
    a = Audit(); requested = report_cases(args.report, a)
    manifest = load_json(args.run_dir / 'collection-manifest.json', a)
    a.eq(manifest.get('requested_count'), 371, 'manifest.requested_count')
    try: a.eq(manifest.get('report_sha256'), hashlib.sha256(args.report.read_bytes()).hexdigest(), 'manifest.report_sha256')
    except OSError: pass
    catalogs = {}; results = {}; groups = {}; all_catalog_keys = set(); all_raw_keys = set()
    for group, expected_count in GROUP_COUNTS.items():
        catrows = load_rows(args.run_dir / f'{group}.catalog.jsonl', a)
        rows = load_rows(args.run_dir / f'{group}.jsonl', a)
        catalogs[group] = index_rows(catrows, group + '.catalog', a)
        results[group] = index_rows(rows, group + '.raw', a)
        a.eq(len(catrows), expected_count, group + '.catalog_count'); a.eq(len(rows), expected_count, group + '.raw_count')
        a.eq(set(results[group]), set(catalogs[group]), group + '.raw_catalog_keys')
        a.check(not all_catalog_keys.intersection(catalogs[group]), group + '.catalog', 'cross-collector duplicate keys')
        a.check(not all_raw_keys.intersection(results[group]), group + '.raw', 'cross-collector duplicate keys')
        all_catalog_keys.update(catalogs[group]); all_raw_keys.update(results[group])
        try:
            names = (args.run_dir / f'{group}.cases').read_text().splitlines()
            a.eq(names, [r['case_name'] for r in catrows], group + '.case_file_catalog_order')
        except OSError as exc: a.check(False, group + '.cases', str(exc))
        entry = manifest.get('collectors', {}).get(group, {})
        a.eq(entry.get('count'), expected_count, 'manifest.' + group + '.count')
        binary = Path(entry.get('binary', '/nonexistent'))
        try: a.eq(entry.get('binary_sha256'), hashlib.sha256(binary.read_bytes()).hexdigest(), 'manifest.' + group + '.binary_sha256')
        except OSError as exc: a.check(False, str(binary), f'cannot verify collector artifact: {exc}')
        before = len(a.failures)
        for k, row in results[group].items():
            if k not in catalogs[group]: continue
            try: check_row(row, catalogs[group][k], group, a)
            except (KeyError, TypeError, ValueError, ZeroDivisionError, OverflowError) as exc:
                a.check(False, group + ':' + str(k), f'malformed measurement metadata: {type(exc).__name__}: {exc}')
        groups[group] = {'catalog_count': len(catrows), 'raw_count': len(rows), 'status_counts': dict(Counter(r.get('status', 'MISSING') for r in rows)), 'row_failures': len(a.failures) - before}
    a.eq(all_catalog_keys, requested, 'catalog.exact_371_keys')
    a.eq(all_raw_keys, requested, 'raw.exact_371_keys')
    core_environment = {(r.get('device'), r.get('cuda_driver'), r.get('cuda_runtime'), r.get('cudnn_version')) for r in results['core'].values() if r.get('status') == 'PASS'}
    a.eq(len(core_environment), 1, 'core.uniform_device_and_software')
    counts = Counter((r.get('op'), r.get('tensors', [{}])[0].get('dtype')) for rs in results.values() for r in rs.values())
    a.eq(counts[('batchnorm', 'fp16')], 12, 'coverage.batchnorm.fp16'); a.eq(counts[('batchnorm', 'bfloat16')], 12, 'coverage.batchnorm.bfloat16')
    a.eq(counts[('reduction', 'fp16')], 6, 'coverage.reduction.fp16'); a.eq(counts[('reduction', 'bfloat16')], 14, 'coverage.reduction.bfloat16')
    a.warnings.append('This validates recorded evidence, not a GPU rerun or recomputation from output tensors. Aux device/software and collector source contents must also be preserved in the external environment/source archive.')
    summary = {'status': 'PASS' if not a.failures else 'FAIL', 'run_dir': str(args.run_dir.resolve()), 'expected_cases': 371, 'observed_unique_cases': len(all_raw_keys), 'passed_measurements': sum(r.get('status') == 'PASS' for rs in results.values() for r in rs.values()), 'checked_assertions': a.checked_assertions, 'groups': groups, 'core_environment': [dict(zip(('device', 'cuda_driver', 'cuda_runtime', 'cudnn_version'), x)) for x in sorted(core_environment)], 'failure_count': len(a.failures), 'failure_categories': dict(Counter(x['category'] for x in a.failures)), 'failures': a.failures, 'warnings': a.warnings}
    text = json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output: args.output.write_text(text + '\n')
    print(text)
    return 0 if not a.failures else 1

if __name__ == '__main__':
    sys.exit(main())
