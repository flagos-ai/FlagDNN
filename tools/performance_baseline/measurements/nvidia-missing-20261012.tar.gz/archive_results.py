from collections import Counter
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT=Path('/home/wangbingjie/FlagDNN')
RUN=Path(__file__).resolve().parent
OUT=ROOT/'tools/performance_baseline/measurements'
MID='nvidia-missing-20261012'
OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[json.loads(x) for g in ('core','aux') for x in (RUN/'collection'/f'{g}.jsonl').read_text().splitlines()]
files={}
for directory in (RUN/'collection',):
    for p in directory.rglob('*'):
        if p.is_file():files[p.relative_to(RUN).as_posix()]=p
for name in ('requested-cases.json','requested-cases.txt','core-cases.txt','aux-cases.txt',
             'requested-report-at-collection.md',
             'environment-before.json','environment-start.json','environment-end.json',
             'source-sha256.json','gpu-monitor.csv','collection.stdout','collection.stderr',
             'core-smoke.cases','core-smoke.jsonl','core-smoke.stderr',
             'raw-validation.json','validator-negative-controls.json','validate_raw.py',
             'baseline-merge-validation.json','core-cpu-check.log','aux-cpu-check.log',
             'python-tests.log','merge_results.py','archive_results.py'):
    files[name]=RUN/name
for name in ('nv-missing-aux-smoke.jsonl','nv-missing-aux-smoke.stderr',
             'nv-missing-aux-smoke2.jsonl','nv-missing-aux-smoke2.stderr'):
    files['smoke/'+name]=Path('/tmp')/name
# Snapshot modified collectors and the authoritative fixtures/oracles.
sources=[
 'tools/performance_baseline/benchmark_nvidia_core_catalog.hpp',
 'tools/performance_baseline/benchmark_nvidia_core_validation.hpp',
 'tools/performance_baseline/benchmark_nvidia_cudnn.cpp',
 'tools/performance_baseline/benchmark_nvidia_missing_aux.cpp',
 'tools/performance_baseline/build_benchmark_nvidia_cudnn.sh',
 'tools/performance_baseline/build_benchmark_nvidia_missing_aux.sh',
 'tools/performance_baseline/run_benchmark_nvidia_missing.py',
 'tools/performance_baseline/benchmark_nvidia_extended.py',
 'tools/performance_baseline/check_benchmark_nvidia_core_validation.cpp',
 'backends/nvidia/validation/benchmark/runner.cpp',
 'backends/hygon/validation/benchmark/runner.cpp',
 'backends/hygon/validation/benchmark/native_dtype.cpp',
 'benchmark/common/case.hpp','benchmark/common/pointwise_cases.cpp',
 'benchmark/common/binary_pointwise_cases.cpp','benchmark/common/pointwise_graph_cases.cpp',
 'benchmark/common/batchnorm_inference_cases.cpp','tests/common/pointwise.cpp','tests/common/reduction.cpp',
 'reference/cpu/benchmark.cpp','reference/cpu/matrix.cpp',
 'backends/nvidia/validation/benchmark/graph.cpp',
 'backends/nvidia/validation/benchmark/pointwise.cpp',
 'backends/nvidia/validation/functional/cudnn_pointwise.cpp',
 'backends/nvidia/validation/tensor_io.cpp']
sources += ['benchmark/test_'+op+'.cpp' for op in sorted({r['op'] for r in rows if '_perf_' in r['case_name']})]
for name in sources:files['sources/'+name]=ROOT/name
archive=OUT/(MID+'.tar.gz')
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
    for name,path in sorted(files.items()):
        payload=path.read_bytes()
        item=tarfile.TarInfo(name);item.size=len(payload);item.mtime=0;item.mode=0o644
        tar.addfile(item,io.BytesIO(payload))
archive.write_bytes(gzip.compress(buf.getvalue(),mtime=0))
assert archive.stat().st_size<500*1024,archive.stat().st_size
baseline=json.loads((ROOT/'docs/performance-baseline.json').read_text())
manifest={
 'schema_version':1,'measurement_id':MID,'measured_on':'2026-10-12',
 'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'source_state':'Working-tree collector extensions; source snapshots and SHA256 list are archived.',
 'requested_report':'docs/nvidia-performance-missing-cases-20261012.md',
 'requested_report_sha256_at_collection':json.loads((RUN/'collection/collection-manifest.json').read_text())['report_sha256'],
 'device':{'name':'NVIDIA H100 80GB HBM3','ordinal':0,'uuid':'GPU-1b8f7635-8b3c-b48e-b6b6-229c50627cb0',
           'pci_bus_id':'00000000:9B:00.0','power_limit_w':700,'mig':'Disabled'},
 'software':{'nvidia_smi_driver':'535.183.06','cuda_toolkit':'12.9.86','cuda_driver_api':12090,
             'cuda_runtime_api':12090,'cudnn_package':'9.24.0.43','cudnn_runtime':92400,
             'cudnn_frontend':'1.26.0'},
 'gpu_activity':{
     'observation':'GPU utilization was 0% before and after. A resident 536 MiB allocation (PID 3275245, outside the visible process namespace) remained; six preflight pmon samples showed no compute activity. This is not proof of exclusive device ownership.',
     'collection':'All benchmark subprocesses ran sequentially; one-second power, clock, utilization and memory monitoring is archived.',
     'monitor':'gpu-monitor.csv'},
 'counts':{'requested':371,'passed':371,'failed':0,'operators':22,'core':291,'aux':80,
           'added_validation':{'cpu_full':335,'bit_exact':36},
           'baseline_total_cases':3264,'baseline_total_operators':82},
 'added_case_counts':dict(sorted(Counter(r['op'] for r in rows).items())),
 'timing':{'method':'CUDA events around one CUDA Graph batch; per-call us = batch us / executions',
           'statistic':'nearest_rank_p50','other_percentile':'nearest_rank_p90',
           'excluded':'build, allocation, uploads/downloads, layout conversion, host oracle and validation',
           'profiles':{k:baseline['reference']['measurement']['timing_profiles'][k] for k in ('native','batchnorm_training')}},
 'validation':{'phases':['before_timing','after_timing','after_reset_replay'],
               'full_output_elements_per_phase':135608956,'phase_records':1113,
               'batchnorm_output_checks':360,'inputs_unchanged':True,'padding_and_guards_intact':True,
               'raw_audit_assertions':140080,'raw_audit_negative_controls':16,
               'cpu_python_tests':15,'core_cpu_checker':'PASS','aux_cpu_checker':'PASS',
               'identity_main':'12 BF16 main cases use numeric exact comparison at atol=rtol=0; this is not bit_exact.',
               'identity_aux':'36 BF16/INT32/BOOL auxiliary cases use exact original storage bytes/bits.'},
 'raw_archive':str(archive.relative_to(ROOT)),'raw_archive_sha256':sha(archive),
 'raw_archive_bytes':archive.stat().st_size,
 'archive_files':{name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in sorted(files.items())},
 'preservation':json.loads((RUN/'baseline-merge-validation.json').read_text()),
 'scope':'Appendix 1 only. No peak remeasurement, no modifications to any platform peaks/policies, no Hygon implementation or regression claim. The 491 existing unavailable cases and the 70+12 out-of-scope cases were not retried.'}
(OUT/(MID+'.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'manifest_bytes':(OUT/(MID+'.json')).stat().st_size,'files':len(files)}))
