import copy
from collections import Counter
import datetime
import hashlib
import json
import math
from pathlib import Path
import subprocess

ROOT = Path('/home/wangbingjie/FlagDNN')
RUN = Path(__file__).resolve().parent
MID = 'nvidia-missing-20261012'
BASELINE = ROOT / 'docs/performance-baseline.json'
original_text = (RUN / 'baseline-before.json').read_text()
original = json.loads(original_text)
assert json.loads(BASELINE.read_text()) == original or (
    (RUN/'baseline-merge-validation.json').is_file() and
    hashlib.sha256(BASELINE.read_bytes()).hexdigest() ==
    json.loads((RUN/'baseline-merge-validation.json').read_text())['after_sha256']
), 'baseline changed outside this import'
data = copy.deepcopy(original)
ref = data['reference']
rows = [(group, json.loads(line)) for group in ('core', 'aux')
        for line in (RUN / 'collection' / f'{group}.jsonl').read_text().splitlines()]
requested = {(r['op'], r['case_name']) for r in json.loads((RUN / 'requested-cases.json').read_text())}
assert len(rows) == 371 and {(r['op'],r['case_name']) for _,r in rows} == requested
assert all(r['status'] == 'PASS' and r['correctness']['status'] == 'PASS' for _,r in rows)
pointwise_fields = ['pointwise_mode', 'pointwise_flags', 'relu_lower_clip', 'relu_upper_clip',
                    'relu_lower_clip_slope', 'swish_beta', 'elu_alpha', 'softplus_beta']

def tensor(raw):
    result = {k:raw[k] for k in ('uid','role','dtype','shape','strides','binding_byte_offset')}
    for k in ('semantic_role','virtual','reference_descriptor_shape','reference_descriptor_strides'):
        if raw.get(k): result[k] = raw[k]
    if raw['reference_strides'] != raw['strides']:
        result['reference_strides'] = raw['reference_strides']
        result['reference_layout_conversion_timed'] = False
    if raw['dtype'] == 'bool': result['reference_storage_bits'] = 1
    return result

new = {}
for group,r in rows:
    name,op = r['case_name'],r['op']
    assert name not in ref['cases'] and name not in ref['unavailable_cases']
    samples = r['timing']['samples_us']
    assert all(math.isfinite(v) and v > 0 for v in samples)
    median = sorted(samples)[math.ceil(.5*len(samples))-1]
    assert math.isclose(median,r['timing']['median_us'],rel_tol=1e-10)
    entry = {'op':op,'tensors':[tensor(t) for t in r['tensors'] if t['role']!='intermediate'],
             'time_us':r['timing']['median_us'],'scale_metric':None,
             'timing_profile':'batchnorm_training' if op=='batchnorm' else 'native',
             'validation':'bit_exact' if r['correctness']['scope']=='bit_exact' else 'cpu_full',
             'measurement_id':MID}
    if group=='core':
        attrs = r['attributes']
        entry['attributes'] = ({k:attrs[k] for k in ('epsilon','momentum')} if op=='batchnorm'
                               else {k:attrs[k] for k in pointwise_fields})
        entry['input_domain'] = r['input_domain']
        entry['input_domains'] = r['input_domains']
        entry['output_count'] = r['output_count']
        entry['input_generation'] = {'source':r['input_generator'],
                                      'domain_definitions':'measurement.supplemental_runs.'+MID+'.input_domains'}
        if op=='add_square':
            entry['intermediate_tensors']=[tensor(t) for t in r['tensors'] if t['role']=='intermediate']
            entry['graph_nodes']=[{k:v for k,v in n.items() if not k.startswith('convolution_')}
                                  for n in r['graph_nodes']]
        assert attrs['alpha']==1
    else:
        attrs = r['attributes']
        if op=='reduction': entry['attributes'] = dict(attrs)
        elif op=='identity':
            entry['attributes']={k:attrs[k] for k in ('flags','relu_lower_clip','relu_upper_clip',
                                                    'relu_lower_clip_slope','swish_beta','alpha')}
        else:
            mapped = dict(attrs,pointwise_mode=attrs['mode'],pointwise_flags=attrs['flags'])
            entry['attributes']={k:mapped[k] for k in pointwise_fields}
        entry['input_generation']=r['inputgen']
    new[name]=entry
ref['cases'].update(new)
ref['measured_on'].append('2026-10-12')
profiles=ref['measurement']['timing_profiles']
profiles['batchnorm_training']={'warmup_iterations':5,'sample_count':10,'iterations_per_sample':20,'graph_warmup_replays':1}
ref['measurement']['collectors'].append('tools/performance_baseline/benchmark_nvidia_missing_aux.cpp')
manifest_path='tools/performance_baseline/measurements/'+MID+'.json'
ref['measurement']['supplemental_runs']={MID:{
    'measured_on':'2026-10-12','source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'source_state':'Working-tree collector extensions; exact source hashes and snapshots are in the measurement archive.',
    'manifest':manifest_path,'case_count':371,'operator_count':22,
    'validation_counts':{'cpu_full':335,'bit_exact':36},
    'input_domains':{
        'source':'benchmark/common/case.hpp::InputDomain',
        'index':'index is zero-based logical element index; tensor_index is zero-based input index',
        'real_value':'float(int((index * 17 + tensor_index * 11) % 41) - 20) / float(13 + tensor_index)',
        '0':'real_value (kReal)', '1':'abs(real_value) + 0.5F (kPositive)',
        'quantization':'Generate in FP32, scatter by logical strides, then encode to each tensor dtype before the CPU oracle.',
        'scope':'Domains used in this supplement; auxiliary input formulas are also stored per case.'},
    'scope':'Exact 371 Appendix 1 cases. Three full validation phases, inputs and guards checked. No changes to platform peaks or policies.'}}
coverage=ref['coverage']
coverage['catalog_limits']['int32'] += (' The 2026-10-12 auxiliary INT32 identity supplement instead uses INT32 computation and exact encoded-byte copy validation; its workload is the matching Hygon fixture.')
coverage['case_count']=len(ref['cases'])
coverage['operator_count']=len({r['op'] for r in ref['cases'].values()})
coverage['case_counts']=dict(sorted(Counter(r['op'] for r in ref['cases'].values()).items()))
coverage['validation_counts']=dict(Counter(r['validation'] for r in ref['cases'].values()))
assert data['platforms']==original['platforms']
assert all(ref['cases'][k]==v for k,v in original['reference']['cases'].items())
assert ref['unavailable_cases']==original['reference']['unavailable_cases']
assert all(profiles[k]==v for k,v in original['reference']['measurement']['timing_profiles'].items())

# Replace only the selected reference fields; all previous case lines and
# platform objects keep their original bytes and formatting.
def replace_value(text,key,value):
    marker='    '+json.dumps(key)+': '
    start=text.index(marker,text.index('  "reference": {'))+len(marker)
    _,length=json.JSONDecoder().raw_decode(text[start:])
    replacement=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)
    replacement=replacement.replace('\n','\n    ')
    return text[:start]+replacement+text[start+length:]
text=original_text
for key in ('measured_on','measurement','coverage'):
    text=replace_value(text,key,ref[key])
marker='    "cases": '
start=text.index(marker,text.index('  "reference": {'))+len(marker)
_,length=json.JSONDecoder().raw_decode(text[start:])
end=start+length
old_cases_text=text[start:end]
assert old_cases_text.endswith('\n    }')
additions=',\n'.join('      '+json.dumps(k)+': '+json.dumps(v,ensure_ascii=False,allow_nan=False) for k,v in new.items())
new_cases_text=old_cases_text[:-len('\n    }')]+',\n'+additions+'\n    }'
text=text[:start]+new_cases_text+text[end:]
assert json.loads(text)==data
assert len(text.encode())<3072*1024, len(text.encode())
BASELINE.write_text(text)
(RUN/'baseline-merge-validation.json').write_text(json.dumps({
    'original_case_count':2893,'added_case_count':371,'case_count':coverage['case_count'],
    'operator_count':coverage['operator_count'],'old_cases_unchanged':True,
    'old_unavailable_cases_unchanged':True,'all_platform_objects_unchanged':True,
    'old_timing_profiles_unchanged':True,'new_scale_metrics_all_null':True,
    'before_sha256':hashlib.sha256(original_text.encode()).hexdigest(),
    'after_sha256':hashlib.sha256(text.encode()).hexdigest(),'bytes':len(text.encode())},indent=2)+'\n')
print((RUN/'baseline-merge-validation.json').read_text())
